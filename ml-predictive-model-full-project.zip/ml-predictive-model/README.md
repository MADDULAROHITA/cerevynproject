# AI / ML Engineer – Predictive Model for Real-World Data

## Project Structure
- data.csv : Sample dataset
- train_model.py : Model training script

## How to Run
python train_model.py
